# studentclearinghouse
A module for creating requests for and processing responses from the National Student Clearinghouse.
