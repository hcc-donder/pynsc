from __future__ import annotations

class NSCError(Exception):
    pass

class NSCConfigurationError(Exception):
    pass
